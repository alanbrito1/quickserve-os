<?php
/**
 * public_html/inventario/index.php
 * Vista principal del inventario: stock actual, alertas y ajustes manuales.
 */

require_once __DIR__ . '/../app/middleware/auth_check.php';
require_once __DIR__ . '/../app/models/InsumoModel.php';

permiso_requerir('inventario', 'solo_ver');

$insumos = InsumoModel::todos_con_estado();

// Resumen
$total    = count($insumos);
$bajos    = count(array_filter($insumos, fn($i) => $i['estado'] === 'bajo'));
$agotados = count(array_filter($insumos, fn($i) => $i['estado'] === 'agotado'));
$ok       = $total - $bajos - $agotados;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventario — <?= APP_NAME ?></title>
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root { --brand:#e94f37; --dark:#111827; --g2:#374151; --g5:#6b7280; --g8:#d1d5db; --g9:#f3f4f6; --white:#fff; --green:#059669; --yellow:#d97706; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: var(--g9); min-height:100vh; color:var(--dark); }

        /* Header */
        .hdr { background:var(--dark); color:var(--white); height:54px; padding:0 14px; display:flex; align-items:center; justify-content:space-between; position:sticky; top:0; z-index:50; box-shadow:0 2px 8px rgba(0,0,0,.3); }
        .brand { font-size:17px; font-weight:800; } .brand span{color:var(--brand);}
        .nav { display:flex; gap:6px; }
        .nl { color:var(--g8); text-decoration:none; font-size:13px; padding:5px 10px; border-radius:8px; }
        .nl:hover { background:var(--g2); color:var(--white); } .nl.act { background:var(--brand); color:var(--white); }

        .main { padding:16px 14px; max-width:960px; margin:0 auto; }

        /* Stats */
        .stats { display:grid; grid-template-columns:repeat(3,1fr); gap:10px; margin-bottom:16px; }
        .stat { background:var(--white); border-radius:14px; padding:14px; box-shadow:0 1px 4px rgba(0,0,0,.06); }
        .stat-n { font-size:24px; font-weight:800; }
        .stat-l { font-size:11px; color:var(--g5); text-transform:uppercase; letter-spacing:.5px; }
        .n-ok  { color:var(--green); } .n-bajo { color:var(--yellow); } .n-ago { color:var(--brand); }

        /* Nav links row */
        .links-row { display:flex; gap:8px; margin-bottom:16px; flex-wrap:wrap; }
        .btn-link {
            padding:9px 16px; border-radius:10px; font-size:13px; font-weight:700;
            text-decoration:none; display:inline-block;
        }
        .btn-primary { background:var(--brand); color:var(--white); }
        .btn-sec     { background:var(--white); color:var(--dark); border:1px solid var(--g8); }

        /* Tabla insumos */
        .card { background:var(--white); border-radius:14px; box-shadow:0 1px 4px rgba(0,0,0,.06); overflow:hidden; }
        table { width:100%; border-collapse:collapse; }
        th { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.5px; color:var(--g5); padding:10px 14px; text-align:left; background:var(--g9); border-bottom:1px solid var(--g8); }
        td { padding:12px 14px; border-bottom:1px solid var(--g9); font-size:14px; vertical-align:middle; }
        tr:last-child td { border-bottom:none; }
        tr:hover td { background:#fafafa; }

        /* Mobile: ocultar columnas menos importantes */
        @media(max-width:600px) { .hide-mobile { display:none; } }

        /* Barra de stock */
        .stock-bar { width:80px; height:6px; background:var(--g8); border-radius:3px; overflow:hidden; display:inline-block; vertical-align:middle; margin-left:6px; }
        .stock-fill { height:100%; border-radius:3px; }
        .fill-ok    { background:var(--green); }
        .fill-bajo  { background:var(--yellow); }
        .fill-ago   { background:var(--brand); }

        /* Estado badge */
        .badge { font-size:10px; font-weight:700; padding:2px 8px; border-radius:20px; text-transform:uppercase; white-space:nowrap; }
        .b-ok   { background:#d1fae5; color:#065f46; }
        .b-bajo { background:#fef3c7; color:#92400e; }
        .b-ago  { background:#fee2e2; color:#991b1b; }

        /* Botón ajuste */
        .btn-ajuste { padding:5px 10px; border:1px solid var(--g8); background:var(--white); border-radius:8px; font-size:12px; font-weight:600; cursor:pointer; color:var(--g2); }
        .btn-ajuste:hover { border-color:var(--brand); color:var(--brand); }

        /* Modal ajuste */
        .overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:60; align-items:center; justify-content:center; padding:16px; }
        .overlay.on { display:flex; }
        .modal { background:var(--white); border-radius:16px; padding:24px; width:100%; max-width:400px; }
        .modal h3 { font-size:16px; font-weight:800; margin-bottom:16px; }
        .fg { display:flex; flex-direction:column; gap:5px; margin-bottom:14px; }
        .fg label { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.5px; color:var(--g5); }
        .fg input, .fg select, .fg textarea { padding:10px 12px; border:2px solid var(--g8); border-radius:10px; font-size:15px; color:var(--dark); width:100%; outline:none; }
        .fg input:focus, .fg select:focus, .fg textarea:focus { border-color:var(--brand); }
        .modal-btns { display:flex; gap:8px; }
        .btn-conf { flex:1; padding:12px; background:var(--brand); color:var(--white); border:none; border-radius:10px; font-size:15px; font-weight:700; cursor:pointer; }
        .btn-canc { flex:1; padding:12px; background:var(--g9); color:var(--g2); border:none; border-radius:10px; font-size:15px; font-weight:700; cursor:pointer; }

        /* Toast */
        .toast { position:fixed; bottom:20px; left:50%; transform:translateX(-50%) translateY(20px); padding:10px 20px; border-radius:24px; font-size:14px; font-weight:600; opacity:0; transition:.25s; z-index:99; pointer-events:none; }
        .toast.on { opacity:1; transform:translateX(-50%) translateY(0); }
        .toast-ok  { background:#065f46; color:#d1fae5; }
        .toast-err { background:#991b1b; color:#fee2e2; }
    </style>
</head>
<body>
<?php $nav_activo = 'inventario'; include __DIR__ . '/../app/views/nav.php'; ?>


<main class="main">

    <!-- Stats -->
    <div class="stats">
        <div class="stat"><div class="stat-n n-ok"><?= $ok ?></div><div class="stat-l">OK</div></div>
        <div class="stat"><div class="stat-n n-bajo"><?= $bajos ?></div><div class="stat-l">Stock Bajo</div></div>
        <div class="stat"><div class="stat-n n-ago"><?= $agotados ?></div><div class="stat-l">Agotados</div></div>
    </div>

    <!-- Acciones rápidas -->
    <div class="links-row">
        <?php if (permiso_tiene('compras','solo_propios')): ?>
        <a href="<?= APP_BASE ?>/inventario/compras.php"        class="btn-link btn-primary">+ Registrar Compra</a>
        <a href="<?= APP_BASE ?>/inventario/lista_compras.php"  class="btn-link btn-sec">📋 Lista de Compras</a>
        <?php endif; ?>
    </div>

    <!-- Tabla de insumos -->
    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>Insumo</th>
                    <th>Stock Actual</th>
                    <th class="hide-mobile">Seguridad</th>
                    <th class="hide-mobile">Costo/u</th>
                    <th>Estado</th>
                    <?php if (permiso_tiene('inventario','editar_existentes')): ?>
                    <th></th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($insumos as $ins):
                    $pct  = min((int)$ins['pct_stock'], 100);
                    $fill = $ins['estado'] === 'ok' ? 'fill-ok' : ($ins['estado'] === 'bajo' ? 'fill-bajo' : 'fill-ago');
                    $badgeC = $ins['estado'] === 'ok' ? 'b-ok' : ($ins['estado'] === 'bajo' ? 'b-bajo' : 'b-ago');
                ?>
                <tr>
                    <td>
                        <strong><?= htmlspecialchars($ins['nombre']) ?></strong>
                        <?php if ($ins['proveedor_nombre']): ?>
                        <br><small style="color:var(--g5)"><?= htmlspecialchars($ins['proveedor_nombre']) ?></small>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?= number_format($ins['stock_actual'], 3, ',', '.') ?>
                        <small style="color:var(--g5)"><?= $ins['unidad_medida'] ?></small>
                        <span class="stock-bar">
                            <span class="stock-fill <?= $fill ?>" style="width:<?= $pct ?>%"></span>
                        </span>
                    </td>
                    <td class="hide-mobile">
                        <?= number_format($ins['stock_seguridad'], 3, ',', '.') ?>
                        <small style="color:var(--g5)"><?= $ins['unidad_medida'] ?></small>
                    </td>
                    <td class="hide-mobile">
                        $<?= number_format($ins['costo_actual'], 0, ',', '.') ?>
                    </td>
                    <td><span class="badge <?= $badgeC ?>"><?= $ins['estado'] ?></span></td>
                    <?php if (permiso_tiene('inventario','editar_existentes')): ?>
                    <td>
                        <button class="btn-ajuste"
                            onclick="abrirAjuste(<?= $ins['id'] ?>,<?= htmlspecialchars(json_encode($ins['nombre'])) ?>,<?= $ins['stock_actual'] ?>,<?= htmlspecialchars(json_encode($ins['unidad_medida'])) ?>)">
                            Ajustar
                        </button>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</main>

<!-- Modal de ajuste de stock -->
<div class="overlay" id="overlay" onclick="if(event.target===this)cerrarModal()">
    <div class="modal">
        <h3 id="modal-titulo">Ajustar Stock</h3>
        <form id="form-ajuste">
            <input type="hidden" id="aj-id">
            <input type="hidden" name="csrf_token" id="aj-csrf" value="<?= htmlspecialchars(csrf_token()) ?>">

            <div class="fg">
                <label>Stock actual</label>
                <input type="text" id="aj-stock-actual" readonly style="background:var(--g9); color:var(--g5)">
            </div>
            <div class="fg">
                <label>Tipo de ajuste</label>
                <select id="aj-tipo" onchange="ajTipoChange()">
                    <option value="entrada">Entrada (+) — compra directa, donación</option>
                    <option value="merma">Merma (−) — vencimiento, derrame</option>
                    <option value="correccion">Corrección (±) — conteo físico</option>
                </select>
            </div>
            <div class="fg">
                <label>Cantidad <span id="aj-unidad"></span></label>
                <input type="number" id="aj-cantidad" placeholder="0.000" step="0.001" min="0.001" required>
            </div>
            <div class="fg">
                <label>Motivo (opcional)</label>
                <input type="text" id="aj-motivo" placeholder="Ej: conteo físico, merma por vencimiento…">
            </div>
            <div class="modal-btns">
                <button type="submit" class="btn-conf">Confirmar</button>
                <button type="button" class="btn-canc" onclick="cerrarModal()">Cancelar</button>
            </div>
        </form>
    </div>
</div>

<div class="toast" id="toast"></div>

<script>
let ajusteInsumoId = null;
let ajusteStockActual = 0;

function abrirAjuste(id, nombre, stock, unidad) {
    ajusteInsumoId   = id;
    ajusteStockActual = parseFloat(stock);
    document.getElementById('modal-titulo').textContent   = 'Ajustar: ' + nombre;
    document.getElementById('aj-id').value                = id;
    document.getElementById('aj-stock-actual').value      = stock + ' ' + unidad;
    document.getElementById('aj-unidad').textContent      = '(' + unidad + ')';
    document.getElementById('aj-tipo').value              = 'entrada';
    document.getElementById('aj-cantidad').value          = '';
    document.getElementById('aj-motivo').value            = '';
    document.getElementById('overlay').classList.add('on');
    document.getElementById('aj-cantidad').focus();
}

function cerrarModal() {
    document.getElementById('overlay').classList.remove('on');
}

function ajTipoChange() {
    const tipo = document.getElementById('aj-tipo').value;
    const lbl  = document.querySelector('label[for] + #aj-cantidad')?.previousElementSibling;
}

document.getElementById('form-ajuste').addEventListener('submit', async function(e) {
    e.preventDefault();
    const tipo     = document.getElementById('aj-tipo').value;
    const cantidad = parseFloat(document.getElementById('aj-cantidad').value);
    const motivo   = document.getElementById('aj-motivo').value.trim();
    if (isNaN(cantidad) || cantidad <= 0) {
        mostrarToast('Ingresa una cantidad válida', 'err');
        return;
    }

    // Determinar delta según tipo
    let delta = cantidad;
    if (tipo === 'merma') delta = -cantidad;
    // correccion: puede ser + o -, permitimos que el usuario ingrese el valor neto

    const fd = new FormData();
    fd.append('csrf_token',  document.getElementById('aj-csrf').value);
    fd.append('insumo_id',   ajusteInsumoId);
    fd.append('delta',       delta);
    fd.append('motivo',      motivo || tipo);

    const btn = this.querySelector('.btn-conf');
    btn.disabled = true;

    const resp = await fetch('api/ajustar_stock.php', { method:'POST', body:fd });
    const data = await resp.json();

    btn.disabled = false;

    if (data.success) {
        cerrarModal();
        mostrarToast('Stock actualizado', 'ok');
        setTimeout(() => location.reload(), 1000);
    } else {
        mostrarToast(data.error || 'Error al ajustar', 'err');
    }
});

let toastTimer;
function mostrarToast(msg, tipo) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.className = 'toast toast-' + tipo + ' on';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('on'), 3000);
}

document.addEventListener('keydown', e => { if (e.key === 'Escape') cerrarModal(); });
</script>
</body>
</html>
