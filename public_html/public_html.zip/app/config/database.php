<?php
/**
 * app/config/database.php
 * Configuración y singleton de conexión PDO.
 *
 * PRODUCCIÓN: Cambiar DB_USER y DB_PASS antes de subir al hosting.
 * SEGURIDAD:  Este archivo NUNCA debe ser accesible vía web (vive en app/, fuera de public_html).
 */

define('DB_HOST',    'localhost');
define('DB_NAME',    'clandestinoERP');
define('DB_USER',    'clandesUSRERP');     // ← cambiar en producción (usuario cPanel)
define('DB_PASS',    '7Ae#rSr;SzDOPCuV');         // ← cambiar en producción
define('DB_CHARSET', 'utf8mb4');

/**
 * Retorna la conexión PDO como singleton lazy.
 * Uso en cualquier archivo: $pdo = db();
 */
function db(): PDO
{
    static $pdo = null;

    if ($pdo !== null) {
        return $pdo;
    }

    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,  // lanza excepciones en error
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,        // arrays asociativos por defecto
            PDO::ATTR_EMULATE_PREPARES   => false,                   // prepared statements reales (previene SQLi)
        ]);
    } catch (PDOException $e) {
        // No exponer datos de conexión al navegador
        error_log('[ClanDestino DB] ' . $e->getMessage());
        http_response_code(503);
        exit('<h1 style="font-family:sans-serif">Error de base de datos. Contacte al administrador.</h1>');
    }

    return $pdo;
}
